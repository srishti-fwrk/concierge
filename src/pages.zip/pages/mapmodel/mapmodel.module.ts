import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MapmodelPage } from './mapmodel';

@NgModule({
  declarations: [
    MapmodelPage,
  ],
  imports: [
    IonicPageModule.forChild(MapmodelPage),
  ],
})
export class MapmodelPageModule {}
