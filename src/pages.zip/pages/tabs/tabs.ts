import { Component } from '@angular/core';

import { MessagesPage } from '../messages/messages';
import { BookPage } from '../book/book';
import { HomePage } from '../home/home';
import { CharterPage } from '../charter/charter';
import { MorePage } from '../more/more';


@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = MessagesPage;
  tab3Root = BookPage;
  tab4Root = CharterPage;
  tab5Root = MorePage;

  constructor() {
    
  }
}
