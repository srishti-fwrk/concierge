import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MembershipplanePage } from './membershipplane';

@NgModule({
  declarations: [
    MembershipplanePage,
  ],
  imports: [
    IonicPageModule.forChild(MembershipplanePage),
  ],
})
export class MembershipplanePageModule {}
