import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import 'rxjs/add/operator/map';
import {LoadingController} from 'ionic-angular';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import { ProfileeditPage } from '../profileedit/profileedit';

/**
 * Generated class for the ProfilePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
profile;srcImage;
 public Loading = this.loadingCtrl.create({
    content: 'Please wait...'
  })
  constructor(public navCtrl: NavController,
  public navParams: NavParams, 
  public http:Http,
  public appsetting: Appsetting,
 public loadingCtrl:LoadingController) {
  this. profilePage()
  }
	profilePage() {

		let headers = new Headers();
		headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
		let options = new RequestOptions({ headers: headers });
		var user_id = localStorage.getItem("USERID")
		// var url = 'http://rakesh.crystalbiltech.com/fash/api/lookbooks/productoflookbook'; 
		var postdata = {
			id: user_id
		};
		console.log(postdata);
		var serialized = this.serializeObj(postdata);
    this.Loading.present();
		this.http.post(this.appsetting.myGlobalVar + 'users/user', serialized, options).map(res => res.json()).subscribe(data => {
			this.Loading.dismiss();

			console.log(data)
			this.profile = data.data.User
			this.srcImage=this.profile.image
			console.log(this.profile)

		})
	}
  serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

    return result.join("&");
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }

    profileeditPage(){
  this.navCtrl.push(ProfileeditPage);
}

}
