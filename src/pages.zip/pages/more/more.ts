import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,App } from 'ionic-angular';
import { ProfilePage } from '../profile/profile';
import { ChangepasswordPage } from '../changepassword/changepassword';
import { PaymentinfoPage } from '../paymentinfo/paymentinfo';
import { SigninPage } from '../signin/signin';
import { MembershipplanePage } from '../membershipplane/membershipplane';
import { SocialSharing } from '@ionic-native/social-sharing';
import { ToastController } from 'ionic-angular';


import { BookdetailsPage } from '../bookdetails/bookdetails';
/**
 * Generated class for the MorePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-more',
  templateUrl: 'more.html',
})
export class MorePage {

  constructor(public navCtrl: NavController, 
  public navParams: NavParams,
  public app: App,private socialSharing: SocialSharing,private toastCtrl: ToastController) {
  }
  socailsharing(){
 //alert("strt")

this.socialSharing.share("Invite friend",null,null,"http://google.com")
.then(()=>{
	//alert("success");
},
()=>{
  let toast = this.toastCtrl.create({
    message: "failed",
    duration: 3000,
    position: 'middle'
  });
  toast.present();
//	alert("failed");
})




}
	public logout() {
 // alert("Logout")
  localStorage.clear();
  let toast = this.toastCtrl.create({
    message: "logged out",
    duration: 3000,
    position: 'middle'
  });
  toast.present();
//	this.navCtrl.push(SigninPage);
	this.app.getRootNav().setRoot(SigninPage);
		

	}
  ionViewDidLoad() {
    console.log('ionViewDidLoad MorePage');
  }

  profilePage(){
  this.navCtrl.push(ProfilePage);
}
  changepasswordPage(){
  this.navCtrl.push(ChangepasswordPage);
}
membershipplanePage(){
  this.navCtrl.push(MembershipplanePage);
}
paymentinfoPage(){
  this.navCtrl.push(PaymentinfoPage);
}
bookdetailsPage(){
  this.navCtrl.push(BookdetailsPage);
}

}
