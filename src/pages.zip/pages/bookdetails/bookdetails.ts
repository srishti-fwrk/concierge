import { Component,ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import 'rxjs/add/operator/map';
import {LoadingController} from 'ionic-angular';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import { ToastController } from 'ionic-angular';
import { LaunchNavigator, LaunchNavigatorOptions } from '@ionic-native/launch-navigator';
/**
 * Generated class for the BookdetailsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-bookdetails',
  templateUrl: 'bookdetails.html',
})
export class BookdetailsPage {

  public data = '';
  longitude: any;
  latitude;
  @ViewChild('map') mapElement;
  map: any;
  bookid: any;dropoff_address;airport_code;date;
  updata;pickup_address;flight_number;airline;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public http:Http,
              public appsetting: Appsetting,
              private toastCtrl: ToastController,
              private launchNavigator: LaunchNavigator,
              public loadingCtrl:LoadingController) {
                this.bookingdetail()
                
  }
  bookingdetail(){
    this.bookid = this.navParams.get('bookid');
    console.log(this.bookid)
    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
    let options = new RequestOptions({ headers: headers });
    var userid = localStorage.getItem("USERID")
    var postdata = {
        user_id:userid,
        bookid: this.bookid
    };
    console.log(postdata);
    var serialized = this.serializeObj(postdata);
    let Loading = this.loadingCtrl.create({
      content: 'Please wait...'
    })
    Loading.present().then(()=>{
    this.http.post(this.appsetting.myGlobalVar + 'bookCabs/bookingdetails', serialized, options).map(res => res.json()).subscribe(data => {
      Loading.dismiss();
      console.log(data)
      if(data.status == 1){
        this.updata = data.data.BookCab
        this.date = this.updata.created
        console.log(this.date)
        this.airline = this.updata.airline
        this.airport_code = this.updata.airport_code
        this.dropoff_address = this.updata.dropoff_address
        this.flight_number = this.updata.flight_number
        this.pickup_address = this.updata.pickup_address 
        console.log(this.updata)
      }else{
        alert(data.msg)
      }
    
  
    })
  });
  }
  
  // loadMap1(){
    
  //    // this.geolocation.getCurrentPosition().then((resp) => {
  //    // resp.coords.latitude
  //    // resp.coords.longitude
  //    // console.log(resp.coords.latitude);
  //    // console.log(resp.coords.longitude);
  //    //  alert(resp.coords.latitude);
  //    //  alert(resp.coords.longitude);
  //    this.latitude = "25.1216";
  //    this.longitude = "55.3774";
    
  //    let latLng = new google.maps.LatLng(this.latitude,this.longitude); 
    
  //    let mapOptions = {
  //    center: latLng,
  //    zoom: 15,
  //    mapTypeId: google.maps.MapTypeId.ROADMAP
  //    }; 
  //    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  //     var marker = new google.maps.Marker({
  //     position: latLng,
  //     map: this.map,
  //   });
 
  googlemap(){
    alert("bhumika")
    let options: LaunchNavigatorOptions = {
      start: 'London, ON',
    //  app: LaunchNavigator.APPS.UBER
    };
    
    this.launchNavigator.navigate('Toronto, ON', options)
      .then(
        success => console.log('Launched navigator'),
        error => console.log('Error launching navigator', error)
      );

  }
    // alert(this.latitude+'/'+this.longitude);
   //  }).catch((error) => {
   //  console.log('Error getting location', error);
    // alert(error)
   //  let toast = aa.toastCtrl.create({
   //  message: 'Please on your location',
   //  duration: 3000,
   //  cssClass: 'toastCss',
   //  position: 'bottom',
   //  });
   //  toast.present();
   //  this.diagnostic.switchToLocationSettings();

  serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));
  
    return result.join("&");
  }
  ionViewDidLoad() {
   this.googlemap();
    console.log('ionViewDidLoad BookdetailsPage');
  }

}
