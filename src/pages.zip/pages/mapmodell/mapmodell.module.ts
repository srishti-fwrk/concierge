import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MapmodellPage } from './mapmodell';

@NgModule({
  declarations: [
    MapmodellPage,
  ],
  imports: [
    IonicPageModule.forChild(MapmodellPage),
  ],
})
export class MapmodelPageModule {}
